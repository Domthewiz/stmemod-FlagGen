﻿namespace WinFormsApp3
{
    partial class smm2stuffgen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(smm2stuffgen));
            checkBox1 = new CheckBox();
            textBox1 = new TextBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            label1 = new Label();
            comboBox1 = new ComboBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            checkBox7 = new CheckBox();
            checkBox8 = new CheckBox();
            checkBox9 = new CheckBox();
            checkBox10 = new CheckBox();
            checkBox11 = new CheckBox();
            checkBox12 = new CheckBox();
            checkBox13 = new CheckBox();
            checkBox14 = new CheckBox();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            panel1 = new Panel();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            label4 = new Label();
            comboBox2 = new ComboBox();
            checkBox15 = new CheckBox();
            SuspendLayout();
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(12, 54);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(71, 19);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "In a Pipe";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Courier New", 19F);
            textBox1.Location = new Point(14, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(129, 36);
            textBox1.TabIndex = 1;
            textBox1.Text = "06000040";
            textBox1.TextAlign = HorizontalAlignment.Center;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(12, 79);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(82, 19);
            checkBox2.TabIndex = 3;
            checkBox2.Text = "Has Wings";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(12, 104);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(80, 19);
            checkBox3.TabIndex = 4;
            checkBox3.Text = "Alt Variant";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.Control;
            label1.Location = new Point(11, 129);
            label1.Name = "label1";
            label1.Size = new Size(87, 15);
            label1.TabIndex = 6;
            label1.Text = "Pipe Direction :";
            label1.Click += label1_Click;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Right", "Left", "Up (Default)", "Down" });
            comboBox1.Location = new Point(98, 126);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(110, 23);
            comboBox1.TabIndex = 5;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(105, 54);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(103, 19);
            checkBox4.TabIndex = 7;
            checkBox4.Text = "Stretch Boo (?)";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(105, 79);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(103, 19);
            checkBox5.TabIndex = 8;
            checkBox5.Text = "In a Clown Car";
            checkBox5.UseVisualStyleBackColor = true;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Location = new Point(105, 104);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(82, 19);
            checkBox6.TabIndex = 9;
            checkBox6.Text = "On a Track";
            checkBox6.UseVisualStyleBackColor = true;
            checkBox6.CheckedChanged += checkBox6_CheckedChanged;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Location = new Point(224, 54);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(122, 19);
            checkBox7.TabIndex = 10;
            checkBox7.Text = "Stacked Enemy (?)";
            checkBox7.UseVisualStyleBackColor = true;
            checkBox7.CheckedChanged += checkBox7_CheckedChanged;
            // 
            // checkBox8
            // 
            checkBox8.AutoSize = true;
            checkBox8.Location = new Point(224, 79);
            checkBox8.Name = "checkBox8";
            checkBox8.Size = new Size(76, 19);
            checkBox8.TabIndex = 11;
            checkBox8.Text = "1.5x Sized";
            checkBox8.UseVisualStyleBackColor = true;
            checkBox8.CheckedChanged += checkBox8_CheckedChanged;
            // 
            // checkBox9
            // 
            checkBox9.AutoSize = true;
            checkBox9.Location = new Point(224, 104);
            checkBox9.Name = "checkBox9";
            checkBox9.Size = new Size(67, 19);
            checkBox9.TabIndex = 12;
            checkBox9.Text = "2x Sized";
            checkBox9.UseVisualStyleBackColor = true;
            checkBox9.CheckedChanged += checkBox9_CheckedChanged;
            // 
            // checkBox10
            // 
            checkBox10.AutoSize = true;
            checkBox10.Location = new Point(224, 129);
            checkBox10.Name = "checkBox10";
            checkBox10.Size = new Size(79, 19);
            checkBox10.TabIndex = 13;
            checkBox10.Text = "Parachute";
            checkBox10.UseVisualStyleBackColor = true;
            checkBox10.CheckedChanged += checkBox10_CheckedChanged;
            // 
            // checkBox11
            // 
            checkBox11.AutoSize = true;
            checkBox11.Location = new Point(352, 54);
            checkBox11.Name = "checkBox11";
            checkBox11.Size = new Size(80, 19);
            checkBox11.TabIndex = 14;
            checkBox11.Text = "In a Cloud";
            checkBox11.UseVisualStyleBackColor = true;
            checkBox11.CheckedChanged += checkBox11_CheckedChanged;
            // 
            // checkBox12
            // 
            checkBox12.AutoSize = true;
            checkBox12.Location = new Point(352, 79);
            checkBox12.Name = "checkBox12";
            checkBox12.Size = new Size(96, 19);
            checkBox12.TabIndex = 15;
            checkBox12.Text = "In a Cloud (?)";
            checkBox12.UseVisualStyleBackColor = true;
            checkBox12.CheckedChanged += checkBox12_CheckedChanged;
            // 
            // checkBox13
            // 
            checkBox13.AutoSize = true;
            checkBox13.Location = new Point(352, 104);
            checkBox13.Name = "checkBox13";
            checkBox13.Size = new Size(120, 19);
            checkBox13.TabIndex = 16;
            checkBox13.Text = "Trinary Alt Form 2";
            checkBox13.UseVisualStyleBackColor = true;
            checkBox13.CheckedChanged += checkBox13_CheckedChanged;
            // 
            // checkBox14
            // 
            checkBox14.AutoSize = true;
            checkBox14.Location = new Point(352, 130);
            checkBox14.Name = "checkBox14";
            checkBox14.Size = new Size(120, 19);
            checkBox14.TabIndex = 17;
            checkBox14.Text = "Trinary Alt Form 3";
            checkBox14.UseVisualStyleBackColor = true;
            checkBox14.CheckedChanged += checkBox14_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ControlDark;
            label2.Location = new Point(200, 9);
            label2.Name = "label2";
            label2.Size = new Size(262, 15);
            label2.TabIndex = 18;
            label2.Text = "Documentation by HappyLappy and Domthewiz";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(4, 163);
            label3.Name = "label3";
            label3.Size = new Size(63, 15);
            label3.TabIndex = 19;
            label3.Text = "Track Type";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(3, 186);
            button1.Name = "button1";
            button1.Size = new Size(66, 25);
            button1.TabIndex = 20;
            button1.Text = "□ - □";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ControlDark;
            panel1.Location = new Point(-10, 155);
            panel1.Name = "panel1";
            panel1.Size = new Size(489, 5);
            panel1.TabIndex = 21;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(75, 166);
            button2.Name = "button2";
            button2.Size = new Size(24, 56);
            button2.TabIndex = 22;
            button2.Text = "□\r\n|\r\n□";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(105, 166);
            button3.Name = "button3";
            button3.RightToLeft = RightToLeft.Yes;
            button3.Size = new Size(60, 56);
            button3.TabIndex = 23;
            button3.Text = "         □\r\n     \\\r\n□";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button4.Location = new Point(171, 166);
            button4.Name = "button4";
            button4.RightToLeft = RightToLeft.No;
            button4.Size = new Size(60, 56);
            button4.TabIndex = 24;
            button4.Text = "         □\r\n     /\r\n□";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.FlatStyle = FlatStyle.System;
            button5.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button5.Location = new Point(277, 186);
            button5.Name = "button5";
            button5.RightToLeft = RightToLeft.Yes;
            button5.Size = new Size(35, 36);
            button5.TabIndex = 25;
            button5.Text = "◞";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button6.Location = new Point(360, 186);
            button6.Name = "button6";
            button6.Size = new Size(35, 36);
            button6.TabIndex = 25;
            button6.Text = "◝";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.Location = new Point(319, 186);
            button7.Name = "button7";
            button7.Size = new Size(35, 36);
            button7.TabIndex = 26;
            button7.Text = "◜";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.FlatStyle = FlatStyle.System;
            button8.Font = new Font("Segoe UI", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.Location = new Point(236, 186);
            button8.Name = "button8";
            button8.RightToLeft = RightToLeft.Yes;
            button8.Size = new Size(35, 36);
            button8.TabIndex = 27;
            button8.Text = "◟";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.Control;
            label4.Location = new Point(236, 166);
            label4.Name = "label4";
            label4.Size = new Size(118, 15);
            label4.TabIndex = 28;
            label4.Text = "Wall Cling (Wall on) :";
            label4.Click += label4_Click;
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Right", "Left", "Up", "Down (Default)" });
            comboBox2.Location = new Point(360, 163);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(110, 23);
            comboBox2.TabIndex = 29;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // checkBox15
            // 
            checkBox15.AutoSize = true;
            checkBox15.Location = new Point(396, 194);
            checkBox15.Name = "checkBox15";
            checkBox15.Size = new Size(74, 19);
            checkBox15.TabIndex = 30;
            checkBox15.Text = "In a Claw";
            checkBox15.UseVisualStyleBackColor = true;
            checkBox15.CheckedChanged += checkBox15_CheckedChanged;
            // 
            // smm2stuffgen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(474, 232);
            Controls.Add(checkBox15);
            Controls.Add(comboBox2);
            Controls.Add(label4);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(checkBox14);
            Controls.Add(checkBox13);
            Controls.Add(checkBox12);
            Controls.Add(checkBox11);
            Controls.Add(checkBox10);
            Controls.Add(checkBox9);
            Controls.Add(checkBox8);
            Controls.Add(checkBox7);
            Controls.Add(checkBox6);
            Controls.Add(checkBox5);
            Controls.Add(checkBox4);
            Controls.Add(label1);
            Controls.Add(comboBox1);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(textBox1);
            Controls.Add(checkBox1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "smm2stuffgen";
            ShowIcon = false;
            Text = "Super Mario Possamato Maker 2 Flags Generator";
            Load += smm2stuffgen_Load;
            Click += smm2stuffgen_Click;
            MouseClick += smm2stuffgen_MouseClick;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox checkBox1;
        private TextBox textBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private Label label1;
        private ComboBox comboBox1;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private CheckBox checkBox8;
        private CheckBox checkBox9;
        private CheckBox checkBox10;
        private CheckBox checkBox11;
        private CheckBox checkBox12;
        private CheckBox checkBox13;
        private CheckBox checkBox14;
        private Label label2;
        private Label label3;
        private Button button1;
        private Panel panel1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Label label4;
        private ComboBox comboBox2;
        private CheckBox checkBox15;
    }
}